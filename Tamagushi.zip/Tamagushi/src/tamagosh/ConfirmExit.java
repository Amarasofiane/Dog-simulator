package tamagosh;

import java.awt.event.*;
import java.awt.*;

import javax.swing.*;

/**
 * @author AMARA Sofiane
 *
 */
public class ConfirmExit extends JFrame implements ActionListener{
	
	Toolkit k = Toolkit.getDefaultToolkit();
	Dimension tailleEcran = k.getScreenSize();
	JLabel msg = new JLabel("Voulez-vous sauvegarder ?");
	JButton  oui = new JButton("Oui");
	JButton  non = new JButton("Non");
	JButton  cancel = new JButton("Annuler");
	
	public ConfirmExit(){
		setLayout(null);
		msg.setBounds(70,15,180,30);
		oui.setBounds(30, 70, 70, 25);
		non.setBounds(110, 70, 70, 25);
		cancel.setBounds(190,70,79,25);
		
		oui.addActionListener(this);
		non.addActionListener(this);
		cancel.addActionListener(this);
		
		add(msg);
		add(oui);
		add(non);
		add(cancel);
		
		setTitle("Sauvegarder");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBounds(tailleEcran.width/2-160,tailleEcran.height/2-100,300,150);
		setVisible(true);	
	}
	public void actionPerformed(ActionEvent e){
		Object source = e.getSource();
		if (source == oui) {
			Scenne.sauvegarder();
			System.exit(0);
		}else if(source == non){
			System.exit(0);
		}
		if(source == cancel ){
			this.dispose();
		}
	}
	
}
