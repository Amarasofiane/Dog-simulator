package tamagosh;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
/**
 * @author AMARA Sofiane
 *
 */
public class Bienvenu extends JFrame implements ActionListener{
	String lePseudo;
	private String mdp;
	JLabel bnv = new JLabel();
	Icon img = new ImageIcon("src/images/bnv.png");
	
	static Bienvenu jeu;
	Toolkit k = Toolkit.getDefaultToolkit();
	Dimension tailleEcran = k.getScreenSize();
	
	JLabel ntpseudo = new JLabel("pseudo");
	JLabel msgPseudo = new JLabel();
	JTextField pseudo = new JTextField();
	
	JLabel ntMdp = new JLabel("mot de passe");
	JLabel msgPasse = new JLabel();
	JTextField motDePasse = new JTextField();
	
	JButton btn = new JButton("Jouer");
	JButton ins = new JButton("S'inscrir");
	JButton quiter = new JButton("Quiter");
	JPanel pnl = new JPanel();

	public Bienvenu(){
		
		bnv.setIcon(img);
		setLayout(null);
		setTitle("saisir votre pseudo");
		
		Container container = this.getContentPane();
		pseudo.setPreferredSize(new Dimension(100,25));
		motDePasse.setPreferredSize(new Dimension(100,25));
		jeu = this;
		bnv.setBounds(80, 10, 400, 150);
		pnl.setBounds(100, 150, 300, 120);
	
		btn.setBounds(105, 300, 90, 30);
		btn.addActionListener(this);
		ins.setBounds(205, 300, 90, 30);
		ins.addActionListener(this);
		quiter.setBounds(305,300,90,30);
		quiter.addActionListener(this);
		
		pnl.setBorder(BorderFactory.createTitledBorder("connexion"));
	
		pnl.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		
		c.gridx = 0;
		c.gridy = 0;
		c.insets = new Insets(5,10,10,5);
		pnl.add(ntpseudo,c);

		c.gridx = 1;
		c.gridy = 0;
		pnl.add(pseudo,c);

		msgPseudo.setForeground(Color.red);
		c.gridx = 2;
		c.gridy = 0;

		pnl.add(msgPseudo,c);
		
		c.gridx = 0;
		c.gridy = 1;
		pnl.add(ntMdp,c);
		c.gridx = 1;
		c.gridy = 1;
		pnl.add(motDePasse,c);
		
		c.gridx = 2;
		c.gridy = 1;
		msgPasse.setForeground(Color.red);
		pnl.add(msgPasse,c);
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setBounds(tailleEcran.width/2-300,tailleEcran.height/2-200,500,420);
		
		container.add(bnv);
		container.add(pnl);
		container.add(btn);
		container.add(ins);
		container.add(quiter);
		
		setResizable(false);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent a){
		Object source = a.getSource();
		if(source == btn){
			// la class controle � toutes les methodes de controle des acces au fichier de jeu
			Controle c = new Controle(); 
			
			lePseudo = pseudo.getText(); 
			String leMdp = motDePasse.getText();
			int rep;
			// appeler controlePseudo qui est dans la class controle pour controler les valeurs saisies
			rep = c.controleConnexion(lePseudo,leMdp);
		//	System.out.println("mot de passe : "+leMdp+" pseudo : "+lePseudo+" le retour est : "+rep);
			switch(rep){
				case 0: msgPseudo.setText("champ vide");
				 		// fonction controle retourn 0 si le champ est vide 
						msgPasse.setText("");
				break;
				
				case 1:
					// fonction controle retourn 1 si toute est OK
					this.dispose();
					new DetailPartie(lePseudo,leMdp); 
				break;

				case 2: 
						// fonction controle retourn 2 si le pseudo est faux 
						msgPseudo.setText("faux !!"); 
						msgPasse.setText("");
				break;
				
				case 3: 
						// fonction controle retourn 3 si le champ de mot de passe est vide 
						msgPasse.setText("champ vide"); 
						msgPseudo.setText("");
				break;
				
				case 4: 
						// fonction controle retourn 4 si le mot de passe est faux
						msgPasse.setText("faux !!");   
						msgPseudo.setText("");	
				break;
			}
		}
		if(source == quiter){
			System.exit(0);
		}
		if(source == ins){
			this.dispose();
			new Inscription();
		}
		
	}
	
	
	public static void main(String []args){
		new Bienvenu();
	}
	
}
