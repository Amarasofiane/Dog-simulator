package tamagosh;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
/**
 * @author AMARA Sofiane
 *
 */
public class MeileurScore extends JFrame implements ActionListener {
	Controle cont = new Controle();
	JButton ok = new JButton("OK");
	
	JLabel nom1;
	JLabel score1;
	JLabel nom2;
	JLabel score2;
	JLabel nom3 ;
	JLabel score3 ;
	JLabel nom4 ;
	JLabel score4;
	JLabel nom5;
	JLabel score5;
	Toolkit k = Toolkit.getDefaultToolkit();
	Dimension tailleEcran = k.getScreenSize();
	JPanel container;
	public MeileurScore(float [] score,String [] pseudo){
		
		nom1 = new JLabel(pseudo[0]+" :");
		score1 = new JLabel(Float.toString(score[0]));
		nom2 = new JLabel(pseudo[1]+" :");
		score2 = new JLabel(Float.toString(score[1]));
		nom3 = new JLabel(pseudo[2]+" :");
		score3 = new JLabel(Float.toString(score[2]));
		nom4 = new JLabel(pseudo[3]+" :");
		score4 = new JLabel(Float.toString(score[3]));
		nom5 = new JLabel(pseudo[4]+" :");
		score5 = new JLabel(Float.toString(score[4]));
		
		container = new JPanel();
		GridLayout grid = new GridLayout(6, 3);
		grid.setHgap(10);
		grid.setVgap(25);
		
		container.setBorder(BorderFactory.createTitledBorder("Meileurs Scores :"));
	
		this.setLayout(new FlowLayout());
		JLabel lePseudo = new JLabel("pseudo");
		JLabel leScore = new JLabel("score");
		JLabel num = new JLabel("N� ");
		lePseudo.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY));
		leScore.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY));
		num.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY));
		container.setLayout(grid);
		
		container.add(num);
		container.add(lePseudo);
		container.add(leScore);	
		container.add(new JLabel("1."));
		container.add(nom1);
		container.add(score1);
		container.add(new JLabel("2."));
		container.add(nom2);
		container.add(score2);
		container.add(new JLabel("3."));
		container.add(nom3);
		container.add(score3);
		container.add(new JLabel("4."));
		container.add(nom4);
		container.add(score4);
		container.add(new JLabel("5."));
		container.add(nom5);		
		container.add(score5);
		
		add(container);
		
		ok.addActionListener(this);
		ok.setPreferredSize(new Dimension(100,25));
		add(ok);
		
		setTitle("Meileurs scores");
		setResizable(false);
		setBounds(tailleEcran.width/2-250,tailleEcran.height/2-170,300,340);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == ok){
			this.dispose();;
		}
	}

	
}
