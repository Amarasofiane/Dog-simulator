package tamagosh;

import java.io.*;

/**
 * @author AMARA Sofiane
 *
 */
public class Controle{
	public static int controlePseudo(String ps,String mdp){
		// si le champs pseudo est vide on retourne 0
		if(ps.equals("")){
			return 0; // 
		}
		// si le mot de passe est vide on retourn 3
		if(mdp.equals("")){
			return 3;
		}
		
		boolean existe = false;
		String laChainne;
	    InputStream fis;
	    InputStreamReader isr;
	    BufferedReader bis;        
	    try {
	      fis = new FileInputStream(new File("src/text/pseudo.txt"));
	      isr = new InputStreamReader(fis);
	      bis = new BufferedReader(isr);
	      
	      try{		
	    	  while (!existe && (laChainne = bis.readLine()) != null) { 
	    		  String elem[] = laChainne.split(";");
	    		  if(elem[0].equals(ps)){
	    			  existe = true;
	    		  }
	    	  }
	      }catch(NumberFormatException e){
	    	  e.printStackTrace();
	      }
	      				
	      bis.close();
	                
	    } catch (FileNotFoundException e) {
	      e.printStackTrace();
	    } catch (IOException e) {
	      e.printStackTrace();
	    }
	    if(existe){
	    	return 1; 
	    }
	    return 2;
	}
	
	
	public int controleConnexion(String ps,String mdp){
		
		 // si le champs est vide on retourn 0;
		if(ps.equals("")){
			return 0; 
		}
		
		if(mdp.equals("")){
			return 3;
		}
		
		boolean existe = false;
		int entree = 0;
		String laChainne;
	    InputStream fis;
	    InputStreamReader isr;
	    BufferedReader bis;        
	    try {
	      fis = new FileInputStream(new File("src/text/pseudo.txt"));
	      isr = new InputStreamReader(fis);
	      bis = new BufferedReader(isr);
	      
	      try{		
	    	  while (!existe && (laChainne = bis.readLine()) != null) { 
	    		  String elem[] = laChainne.split(";");
	    		  if(elem[0].equals(ps)){
	    			  entree ++;
	    			  if(elem[1].equals(mdp)){
	    				  existe = true;
	    			  }
	    		  }
	    	  }
	      }catch(NumberFormatException e){
	    	  e.printStackTrace();
	      }

	      bis.close();
	                
	    } catch (FileNotFoundException e) {
	      e.printStackTrace();
	    } catch (IOException e) {
	      e.printStackTrace();
	    }
	    // si le mot de passe et le pseudo sont juste
	    if(existe){ 
	    	return 1;
	    }
	    // si le pseudo est juste mais pas le mot de passe
	    if(entree == 1){  
	    	return 4;
	    }
	    return 2; // 
	}
	
	public static void read(String ps){
		
	    //Nous d�clarons nos objets en dehors du bloc try/catch
	    InputStream fis;
	    InputStreamReader isr;
	    BufferedReader bis;
	    String line;
	    boolean trouver = false;
	    try {
	      fis = new FileInputStream(new File("src/text/pseudo.txt"));
	      isr = new InputStreamReader(fis);
	      bis = new BufferedReader(isr);
	      
	      while (!trouver && ((line = bis.readLine()) != null)) {
	    	  String elem[] = line.split(";");
	    	  if(elem[0].equals(ps)){
	    		
	    		  Scenne.x = Integer.parseInt(elem[2]);
	    		  Scenne.y = Integer.parseInt(elem[3]);
	    		  Chien.score =  Float.parseFloat(elem[4]);
	    		  Chien.vie =  Float.parseFloat(elem[5]);
	    		  Chien.humeur =  Float.parseFloat(elem[6]);
	    		  Chien.faim =  Float.parseFloat(elem[7]);
	    		  Chien.fatigue =  Float.parseFloat(elem[8]);
	    		  Chien.hygienne =  Float.parseFloat(elem[9]);
	    		  Chien.sommeil =  Float.parseFloat(elem[10]);
	    		  Chien.temps = Float.parseFloat(elem[11]);
	    		  Chien.nbParties = Integer.parseInt(elem[12]);
	    		  trouver = true;
	    	  }
	      }
	      bis.close();
	    }catch (FileNotFoundException e) {
	      e.printStackTrace();
	    } catch (IOException e) {
	      e.printStackTrace();
	    }  	
	}
	
	public void sauvegarder(String ps,String mdp){
		  
		  try {
			 BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("src/text/pseudo.txt")));
		     StringBuffer sb = new StringBuffer(); 
	         String line;      
	         while ((line = reader.readLine()) != null) {
	        	 String elem[] = line.split(";");
	             if (!elem[0].equals(ps)){
	                 sb.append(line);
	                 sb.append(System.getProperty("line.separator"));
	             }
	         }
	         reader.close();
	         
	         BufferedWriter out = new BufferedWriter(new FileWriter("src/text/pseudo.txt"));
	         out.write(ps+";"+mdp+";"+Scenne.x+";"+Scenne.y+";"+Chien.score+";"+Chien.vie+";"+Chien.humeur+";"+Chien.faim+";"+Chien.fatigue+";"+Chien.hygienne+";"+Chien.sommeil+";"+Chien.temps+";"+Chien.nbParties);
	         out.write(System.getProperty("line.separator"));
	         out.write(sb.toString());
	         //out.newLine();
	         out.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
	      
	}
	
	public void meileurScore(){
		 
		  try {
			  int i = 0,j,nbElement = 0;
			  String line;
			  BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("src/text/pseudo.txt")));
			  float tab[] = new float[5];
			  String tab2[] = new String[5];
			  
			  while ((line = reader.readLine()) != null){
				  String elem[] = line.split(";");//deviser la ligne recuper� separ� par des points virgules en un tableau 
				  if(nbElement<5){
					  // inserer le score dans le tableau qui est a la position 4
					  tab[nbElement] = Float.parseFloat(elem[4]);
					  // insere le pseudo qui correspond au score 
					  tab2[nbElement] = elem[0]; 
					  nbElement++;
					
				  }else{
					 triTable(tab,tab2);
					 if(Float.parseFloat(elem[4]) > tab[nbElement-1]){
						 tab[nbElement-1] = Float.parseFloat(elem[4]);
						 tab2[nbElement-1] = elem[0];
					 }
				  }
				  triTable(tab,tab2);
			  }
			  
			  
			  afficheScore(tab,tab2);
			  reader.close();	         
	        
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void triTable(float tab[],String tab2[]){
		int i,j,ind=0;
		String tmp2;
		float max, tmp;
		
		for(i=0;i<tab.length-1;i++){
			max = tab[i];
			for(j=i+1;j<tab.length;j++){
				if(max<tab[j]){
					max = tab[j];
					ind = j;
				}
			}
			if(max != tab[i]){
				tmp = tab[i];
				tmp2 = tab2[i];
				
				tab[i] = tab[ind];
				tab2[i] = tab2[ind];
				
				tab[ind] = tmp;
				tab2[ind] = tmp2;
			}
		}
	}
	
	public void afficheScore(float scores[], String pseudo[]){
		new MeileurScore(scores,pseudo);
	}
	
	public void statistique(String pseudo){
		  try {
			  	 float stat[] = new float[3];
			  	 
				 BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("src/text/pseudo.txt")));
			    
		         String line;
		         boolean trouve = false;
		         while (!trouve && (line = reader.readLine()) != null) {
		        	 String elem[] = line.split(";");
		             if (elem[0].equals(pseudo)){
		                 trouve = true;
		                 stat[0] = Float.parseFloat(elem[4]);
		                 stat[1] = Float.parseFloat(elem[11]);
		                 stat[2] = Float.parseFloat(elem[12]);
		             }
		         }
		         
		         if(trouve){
		        	 faireStatistique(stat);
		         }
		         reader.close();
		  } catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		      
		}
		 
	public void faireStatistique(float stats[]){
		new Statistiques(stats);
	}
	
	public void inscriptionDe(String ps, String mdp){
		  try {
			 // int i = 0; 
				 BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("src/text/pseudo.txt")));
			     StringBuffer sb = new StringBuffer(); 
		         String line;      
		         while((line = reader.readLine()) != null) {
		        	 // on stock toutes les donn�es existantes dans notre fichier text et on les mets dans le buffer "reader"
		        	 sb.append(line);
		        	 // ajouter un saut de ligne
		        	 sb.append(System.getProperty("line.separator")); 
		         }
		         reader.close();
		         
		         BufferedWriter out = new BufferedWriter(new FileWriter("src/text/pseudo.txt"));
		         out.write(ps+";"+mdp+";"+200+";"+200+";"+0+";"+100+";"+100+";"+100+";"+100+";"+100+";"+100+";"+0+";"+0);// on insert le nouveau inscrit
		         // et puis on ajoute un saut de ligne pour separer
		         out.newLine();
		         // et puis on ajoute les ancienne donn�e du fichier text qu on a stock� dans le buffer
		         out.write(sb.toString());
		         out.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	

}
	
	