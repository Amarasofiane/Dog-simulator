package tamagosh;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
/**
 * @author AMARA Sofiane
 *
 */
public class Scenne extends JFrame implements KeyListener, ActionListener {
	private int deb = 0;
	private static String pseudo;
	private static String motDePasse;

	
	int largeur ;
	int hauteur ;
	
	JMenuBar mb = new JMenuBar();
	JMenu fichier = new JMenu();
	JMenu stat = new JMenu();
	
	JMenuItem nvp = new JMenuItem();
	JMenuItem sp = new JMenuItem();
	JMenuItem quiter = new JMenuItem();
	
	JMenuItem m_s = new JMenuItem("Meilleurs scores");
	JMenuItem g_s = new JMenuItem("global_stat");
	
	JButton btn = new JButton("clique");
	public static int  x=100;
	public static int  y=100;
	Toolkit k = Toolkit.getDefaultToolkit();
	Dimension tailleEcran = k.getScreenSize();
	
	public static Chien chiens;

	static Controle c = new Controle();
	// la classe de controle : de sauvegarde de calcule
	JPanel pnl = new JPanel();
	public Scenne(String pseudo, String mdp, int part){
		this.motDePasse = mdp;
		this.pseudo = pseudo;

		setLayout(new BorderLayout());
		
		chiens = new Chien(pseudo);
		fichier.setText("Fichier");
		nvp.setText("nouvelle partie");
		nvp.setEnabled(true);
		nvp.addActionListener(this);
		
		sp.setText("Sauvegarder la partie");
		sp.addActionListener(this);
		quiter.setText("Quiter");
		quiter.addActionListener(this);
		
		fichier.add(nvp);
		fichier.add(sp);
		fichier.add(quiter);
		
		stat.setText("statistique");
		m_s.addActionListener(this);
		g_s.addActionListener(this);
		stat.add(m_s);
		stat.add(g_s);
		
		
		//fichier.setMnemonic(KeyEvent.VK_F);
		
		mb.add(fichier);
		mb.add(stat);
		setJMenuBar(mb);
		addKeyListener(this);
		
		setContentPane(chiens);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	    addWindowListener(new WindowAdapter() {
	        @Override
	        public void windowClosing(WindowEvent event) {
	        	confirmationExit();
	        }
	    });
	    
		setLocationRelativeTo(null);
		setBounds(tailleEcran.width/2-520,tailleEcran.height/2-350,1100,650);
		setResizable(false);
		setVisible(true);
		
		Controle.read(pseudo);
		if(part == 0){
			nouvellePartie();
		}
		// decloncher le le coeur de jeu dans un autre thread 
		new Mouteur(chiens).start(); 
	}
	
	public void confirmationExit(){
		new ConfirmExit(); 
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		largeur = this.getSize().width-80;
		hauteur = this.getSize().height-120;
		int code = e.getKeyCode();
		if(code == KeyEvent.VK_UP){
			//System.out.println("button cliqu� up");
			up();
		}
		if(code == KeyEvent.VK_DOWN){
			down();
		}
		if(code == KeyEvent.VK_LEFT){
			left();
		}
		if(code == KeyEvent.VK_RIGHT){
			right();
		}
	}
	
	public void down(){Chien.imageChien = "src/images/chh.png"; y+=10; if(y>hauteur) y = hauteur; }
	public void up(){Chien.imageChien = "src/images/chhaut.png"; y-=10; if (y < 80 && x < 150) y = 80; if (y < 0 ) y = 0;}
	public void right(){Chien.imageChien = "src/images/chhDroite.png"; x+=10; if(x > largeur) x = largeur;}
	public void left(){Chien.imageChien = "src/images/chh.png"; x-=10; if (x < 150 && y < 80 ) x = 150; if (x < 0 ) x = 0; }
	
	@Override
	public void keyReleased(KeyEvent e){}
	@Override
	public void keyTyped(KeyEvent e){}
	
	public void mouseClicked(MouseEvent e){}
	public void mousePressed(MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	
	public void actionPerformed(ActionEvent e){
		Object source = e.getSource();
		if(source == nvp){
			nouvellePartie();
		}
		if(source == sp)
			sauvegarder();
		if(source == quiter)
			new ConfirmExit();
		if(source == m_s){
			afficherMeilleurScore();
		}
		if(source == g_s){
			stat();
		}
		
	}
	public void nouvellePartie(){
		Chien.nbParties += 1;
		Scenne.x = 300;
		Scenne.y = 300;
		Chien.temps = 0;
		Chien.score = 0;
		Chien.comptRebour = 3;
		Chien.vie = 100;
		Chien.humeur = 100;
		Chien.faim = 100;
		Chien.fatigue = 100;
		Chien.hygienne = 100;
		Chien.sommeil = 100;
		sauvegarder();
	
	}
	public static void sauvegarder(){
		c.sauvegarder(pseudo,motDePasse);
	}
	public void afficherMeilleurScore(){
		c.meileurScore();
	}
	public void stat(){
		c.statistique(pseudo);
	}
	
}