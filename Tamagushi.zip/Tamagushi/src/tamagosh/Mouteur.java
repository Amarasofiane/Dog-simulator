package tamagosh;

import java.awt.Container;
/**
 * @author AMARA Sofiane
 *
 */
public class Mouteur extends Thread {
	//class principale
	Container chiens ;
	public Mouteur(Container c){
		this.chiens=c;
	}
	public void run() {
		while(true){
				
					try {
						Thread.sleep(100);	
					}catch (InterruptedException e) {
						e.printStackTrace();
					}
					chiens.repaint();
				if(Chien.comptRebour <= 0){
					Chien.vie();
					// si le chien est � la ca maison
					if(Scenne.x <= 880 && Scenne.x>=800 && Scenne.y<=30 && Scenne.y>=10) Chien.dormir();
					// si le le est � coter de l'assiette
					if(Scenne.x <= 920 && Scenne.x>=840 && Scenne.y<=100 && Scenne.y>=90) Chien.manger(); 
					if(Scenne.x <= 950 && Scenne.x>=840 && Scenne.y<=220 && Scenne.y>=180) Chien.douche();
					
				}else{
					Chien.comptRebour -= .1;
				}
		}
	}
}