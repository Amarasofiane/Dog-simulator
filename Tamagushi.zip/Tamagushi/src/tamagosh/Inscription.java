package tamagosh;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
/**
 * @author AMARA Sofiane
 *
 */
public class Inscription extends JFrame implements ActionListener{
	String lePseudo;
	String mdp;
	Controle controler = new Controle();
	Icon img = new ImageIcon("src/images/bnv.png");
	JLabel bnv = new JLabel();
	static Bienvenu jeu;
	Toolkit k = Toolkit.getDefaultToolkit();
	Dimension tailleEcran = k.getScreenSize();
	
	JLabel ntpseudo = new JLabel("pseudo");
	JLabel msgPseudo = new JLabel();
	JTextField pseudo = new JTextField();
	
	JLabel ntMdp = new JLabel("mot de passe");
	JLabel msgPasse = new JLabel();
	JTextField motDePasse = new JTextField();
	
	JButton valider = new JButton("Inscrire");
	JButton quiter = new JButton("Quiter");
	JPanel pnl = new JPanel();

	public Inscription(){
		setLayout(null);
		setTitle("Inscription");
		bnv.setIcon(img);	
		motDePasse.setPreferredSize(new Dimension(100,20));
		pseudo.setPreferredSize(new Dimension(100,20));
		
		bnv.setBounds(80, 10, 400, 150);
		pnl.setBounds(100, 150, 300, 120);
	
		valider.setBounds(135, 300, 100, 30);
		valider.addActionListener(this);
		quiter.setBounds(250,300,100,30);
		quiter.addActionListener(this);
		
		pnl.setBorder(BorderFactory.createTitledBorder("inscription"));
		pnl.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		
		c.gridx = 0;
		c.gridy = 0;
		c.insets = new Insets(5,10,10,5);
		pnl.add(ntpseudo,c);
		c.gridx = 1;
		c.gridy = 0;
		pnl.add(pseudo,c);

		msgPseudo.setForeground(Color.red);
		c.gridx = 2;
		c.gridy = 0;

		pnl.add(msgPseudo,c);
		
		c.gridx = 0;
		c.gridy = 1;
		pnl.add(ntMdp,c);
		c.gridx = 1;
		c.gridy = 1;
		pnl.add(motDePasse,c);
		
		c.gridx = 2;
		c.gridy = 1;
		msgPasse.setForeground(Color.red);
		pnl.add(msgPasse,c);
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setBounds(tailleEcran.width/2-300,tailleEcran.height/2-200,500,420);
		
		add(bnv);
		add(pnl);
		add(valider);
		add(quiter);
		
		setResizable(false);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent a){
		Object source = a.getSource();
		if(source == valider){
			lePseudo = pseudo.getText(); 
			String leMdp = motDePasse.getText();
			int rep;
					// appeler controlePseudo qui est dans la class controle pour controler les valeurs saisies
					rep = Controle.controlePseudo(lePseudo,leMdp);
			switch(rep){
				case 0: 
						// fonction controle retourn 0 si le champ est vide 
						msgPseudo.setText("champ vide"); 
						msgPasse.setText("");
				break;
				case 1:	// fonction controle retourn 0 si le pseudo existe
						msgPseudo.setText("existant");  
						msgPasse.setText("");
				break;
				case 2: // fonction controle retourn 2 si toute est OK
						this.dispose();
						new Bienvenu(); 
						controler.inscriptionDe(lePseudo,leMdp);
				break;
				case 3: // fonction controle retourn 0 si le champ est vide
						msgPasse.setText("champ vide");  
						msgPseudo.setText("");
				break;
			
			}
		}
		
		if(source == quiter){
			System.exit(0);
		}
		
	}
	
}