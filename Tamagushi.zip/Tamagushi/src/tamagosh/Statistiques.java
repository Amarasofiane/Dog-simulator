package tamagosh;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * @author AMARA Sofiane
 *
 */
public class Statistiques extends JFrame implements ActionListener {
	Controle cont = new Controle();
	JButton ok = new JButton("OK");
	
	private int min = 0;
	private int heurs = 0;
	private int second = 0;
	private String tempS,tempM,tempH;
	
	JLabel nom1;
	JLabel score1;
	JLabel nom2;
	JLabel score2;
	JLabel nom3 ;
	JLabel score3 ;
	
	JPanel container;
	public Statistiques(float [] stat){
		second = (int)stat[1]%60;
		min = (int)stat[1]/60;
		heurs = (int)stat[1]/360;
		if (second < 10){
			tempS = "0"+second;
		}else{
			tempS = ""+second;
		}
		if (heurs < 10){
			tempH = "0"+heurs;
		}else{
			tempS = ""+heurs;
		}
		
		if (min < 10){
			tempM = "0"+min;
		}else{
			tempS = ""+min;
		}
		
		nom1 = new JLabel("");
		
		score1 = new JLabel(Float.toString(stat[0]));
		nom2 = new JLabel("");
		score2 = new JLabel(Integer.toString((int)stat[1]));
		nom3 = new JLabel("");
		score3 = new JLabel(Integer.toString((int)stat[2]));
	
		container = new JPanel();
		GridLayout grid = new GridLayout(4, 2);
		grid.setHgap(100);
		grid.setVgap(25);
		
		container.setBorder(BorderFactory.createTitledBorder("Globales statistiques :"));
		this.setLayout(new FlowLayout());
		container.setLayout(grid);
		JLabel statis = new JLabel("score");
		JLabel valeur = new JLabel("N� ");
		statis.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY));
		valeur.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY));
		
		container.add(statis);
		container.add(valeur);
		container.add(new JLabel("score"));
		container.add(score1);
		container.add(new JLabel("temps jou�"));
		container.add(new JLabel(tempH+":"+tempM+":"+tempS));
		container.add(new JLabel("partie jou�"));
		container.add(score3);

		add(container);
		
		ok.addActionListener(this);
		add(ok);
		
		setTitle("Statistiques");
		setResizable(false);
		setBounds(100,100,300,250);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == ok){
			this.dispose();
		}
	}

	
}