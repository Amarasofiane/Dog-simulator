package tamagosh;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * @author AMARA Sofiane
 *
 */
public class DetailPartie extends JFrame implements ActionListener{
	private String pseudo;
	private String motDePasse;
	Toolkit k = Toolkit.getDefaultToolkit();
	Dimension tailleEcran = k.getScreenSize();
	
	JLabel bnv = new JLabel();
	JButton nouvelle = new JButton("Nouvelle partie");
	JButton continuer = new JButton("Continuer");
	JButton quiter = new JButton("Quiter");
	JButton score = new JButton("Score");
	
	Icon img = new ImageIcon("src/images/bnv.png");

	Container container;
	public DetailPartie(String pseudo, String mdp){
		this.pseudo = pseudo;
		this.motDePasse = mdp;
		
		Controle.read(pseudo);
		bnv.setIcon(img);
		container = this.getContentPane();
		container.setLayout(null);
		setBounds(tailleEcran.width/2-300,tailleEcran.height/2-200,400,400);
		
		bnv.setBounds(40, 10, 400, 150);
		nouvelle.addActionListener(this);
		continuer.addActionListener(this);
		quiter.addActionListener(this);
		score.addActionListener(this);
		
		nouvelle.setBounds(100,150,200,30);
		continuer.setBounds(100,250,200,30);
		quiter.setBounds(100,200,200,30);
		score.setBounds(100,300,200,30);
		
		container.add(bnv);
		container.add(nouvelle);
		container.add(quiter);
		if (Chien.nbParties != 0){
			container.add(score);
			container.add(continuer);
		}
		setVisible(true);
	}
	public void paintComponent(Graphics g){
		g.setColor(Color.RED);
		g.fillRect(10, 10, 250, 250);
	}
	
	public void actionPerformed(ActionEvent e){
		Object source = e.getSource();
		if( source == quiter){
			System.exit(0);
		}
		if( source == nouvelle){
			this.dispose();
			new Scenne(pseudo,motDePasse,0);
		}
		if(source == continuer){
			this.dispose();
			new Scenne(pseudo,motDePasse,1);
		}
		if( source == score){
			Controle c = new Controle();
			c.meileurScore();
		}
		
	}
	
	
}
