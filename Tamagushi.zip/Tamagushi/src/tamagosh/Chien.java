package tamagosh;

import java.awt.*;

import javax.swing.*;

	/**
	 * @author AMARA Sofiane
	 *
	 */
	public class Chien extends JPanel{
		public static float score = 0;
		public static float temps=0;
		public static float comptRebour = 3;
		public static int nbParties = 0;
		public static String etat = "Repos";
		public static String GameOver = "Game Over";
		
		private String pseudo;
		public static float vie = 100;
		public static float humeur = 100;
		public static float faim = 100;
		public static float fatigue = 100;
		public static float hygienne = 100;
		public static float sommeil = 100;
		public static String imageChien = "src/images/chh.png";
		private int min = 0;
		private int heurs = 0;
		private int second = 0;
		private String tempS,tempM,tempH;
		
		JLabel assiette = new JLabel();
		JLabel mange = new JLabel();
		JLabel laDouche = new JLabel();
	
		public Chien(String pseudo){
			this.pseudo = pseudo;
			setLayout(null);
			assiette.setBounds(850, 10, 100, 100);
			mange.setBounds(900	, 90 , 100, 100);
			laDouche.setBounds(880,170,130,130);
			
			assiette.setIcon(new ImageIcon("src/images/niche.png"));
			mange.setIcon(new ImageIcon("src/images/manger3.png"));
			laDouche.setIcon(new ImageIcon("src/images/douche.png"));
			
			add(assiette);
			add(mange);
			add(laDouche);
		}
		
		public void paintComponent(Graphics g){
			g.setColor(new Color(255,255,255));
		
			g.drawImage(new ImageIcon("src/images/fond.jpg").getImage(),0,0, this.getSize().width, this.getSize().height, null);
		
			
			if(vie > 0){
				if(comptRebour >= 0){
					g.setFont(new Font("arial", Font.BOLD, 50));
					g.setColor(new Color(200,10,10));
					g.drawString((int)comptRebour+1+" ", this.getSize().width/2 ,this.getSize().height/2);
					
				}
				g.setFont(new Font("arial", Font.BOLD, 15));
				g.setColor(new Color(205,250,200));
				
				if (second < 10){
					tempS = "0"+second;
				}else{
					tempS = ""+second;
				}
				if (heurs < 10){
					tempH = "0"+heurs;
				}else{
					tempS = ""+heurs;
				}
				
				if (min < 10){
					tempM = "0"+min;
				}else{
					tempS = ""+min;
				}
				g.setColor(new Color(200,150,150));
				
				g.drawString("Score : "+(int)score, 270 ,20);
				g.drawString("Temp : "+tempH+":"+tempM+":"+tempS, 380 ,20);
				
				g.drawString("Etat : "+etat, 540 ,20);
				
				g.setFont(new Font("arial", 1, 12));
				g.setColor(new Color(205,250,200));
				g.drawString("Pseudo : "+pseudo, 15 ,15);
				
				if(vie < 20) g.setColor(new Color(250,0,0));
				g.drawString("vie :    "+(int)vie+"%", 0 ,30);
				g.fillRect(60, 25, (int)vie,5);
				
				g.setColor(new Color(205,250,200)); 
				// reinitialisation 
				
				if(hygienne < 20) g.setColor(new Color(250,0,0));
				g.drawString("hyg :   "+(int)hygienne+"%", 0 ,42);
				g.fillRect(60, 37, (int)hygienne,5);
				g.setColor(new Color(205,250,200)); 
				// reinitialisation
				
				if(faim < 20) g.setColor(new Color(250,0,0));
				g.drawString("faim : "+(int) faim+"%", 0 ,54);
				g.fillRect(60, 49, (int) faim,5);
				g.setColor(new Color(205,250,200)); 
				// reinitialisation
				
				if(sommeil < 20) g.setColor(new Color(250,0,0));
				g.drawString("som : "+(int)sommeil+"%", 0 ,66);
				g.fillRect(60, 61, (int)sommeil,5);
				g.setColor(new Color(205,250,200)); 
				// reinit
				
				if(humeur < 20) g.setColor(new Color(250,0,0));
				g.drawString("hum : "+(int)humeur+"%", 0 ,78);
				g.fillRect(60, 73,(int) humeur,5);
				g.setColor(new Color(205,250,200)); 
				// reinitialisation
				
				g.drawImage(new ImageIcon(imageChien).getImage(), Scenne.x,Scenne.y,null);
				if(comptRebour < 0){
					score += .06;
					temps += .1;
				}
				
				second = (int)temps%60;
				min = (int)temps/60;
				heurs = (int)temps/360;
			}else{
				g.setFont(new Font("arial", Font.BOLD, 50));
				g.setColor(new Color(200,10,10));
				g.drawString(GameOver, this.getSize().width/2 ,this.getSize().height/2);
				Scenne.sauvegarder();
			}
		}

		public static void dormir(){
			sommeil += .5;
			etat = "dort";
			if(sommeil > 100) sommeil = 100;
		}

		public static void vie(){
			faim -= .2;
			etat = "repos";
			if(faim < 0) faim = 0;
			hygienne -= .1;
			if(hygienne < 0) hygienne = 0;
			sommeil -= .1;
			if(sommeil < 0) sommeil = 0;
			fatigue -= .1;
			if(fatigue < 0) fatigue = 0;
			vie = (faim*5+fatigue*4+hygienne*3)/12;
			humeur = (faim+sommeil+hygienne)/3;
		}
			
		public static void manger() {
			faim +=1.5;
			etat = "mange";
			if(faim > 100) faim =100;
		}
		public static void douche() {
			hygienne += 2.2;
			etat = "douche";
			if(hygienne > 100) hygienne =100;
		}
		
	}

